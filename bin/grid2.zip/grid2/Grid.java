package grid2;

import java.util.ArrayList;

public class Grid {

	ArrayList <Row> theSquares = new ArrayList <Row> ();
	
	public Grid() {
		for(int loop = 1; loop <= 10; loop++) {
			Row tempRow;
			tempRow = new Row(loop);
			this.theSquares.add(tempRow);
		}
	}

}
