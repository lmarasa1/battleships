package grid2;

public class Square {
	int number;
	boolean shipOn;
	int value;
	boolean firedAt;
	
	public Square(int number) {
		setNumber(number);
	}
	
	public void setNumber(int number) {
		this.number = number;
	}
}
